from scheduler import generate_instance, Instance
from collections import Counter

data = generate_instance(50, 8, conflict_density=0.25, seed=10)
inst = Instance(data)
print('Windows sample:', inst.windows[:10])
slack_counts = Counter(hi-lo for (lo,hi) in inst.windows)
print('Slack distribution:', dict(slack_counts))
deg = [len(inst.conflict_adj[i]) for i in range(inst.n)]
print('Max conflict degree:', max(deg))
total_res = [sum(inst.resources[i][d] for i in range(inst.n)) for d in range(4)]
total_cap = [sum(inst.capacities[s][d] for s in range(inst.K)) for d in range(4)]
print('Total demand:', [round(x,1) for x in total_res])
print('Total capacity:', total_cap)
print('Ratio:', [round(total_res[d]/total_cap[d],3) for d in range(4)])

