"""
Benchmarking script — Task 6
Runs all 9 required benchmark instances, produces result table and charts.
Usage: python benchmark.py
"""

import json
import time
import math
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scheduler import generate_instance, Instance, solve, brute_force_optimal

BENCHMARKS = [
    # (label,  n,   K,  density, seed, run_brute)
    ("S1",     8,   3,  0.3,     1,    True),
    ("S2",    10,   4,  0.4,     2,    True),
    ("S3",    12,   4,  0.5,     3,    True),
    ("M1",    50,   8,  0.25,   10,    False),
    ("M2",   100,  10,  0.30,   11,    False),
    ("M3",   150,  12,  0.35,   12,    False),
    ("X1",   200,  15,  0.40,   20,    False),
    ("X2",   200,   5,  0.60,   21,    False),  # tight K
    ("X3",   200,  20,  0.10,   22,    False),  # sparse conflicts
]

rows = []
for label, n, K, density, seed, do_brute in BENCHMARKS:
    data = generate_instance(n, K, conflict_density=density, seed=seed)
    inst = Instance(data)

    result = solve(inst)
    row = {
        "label": label,
        "n": n,
        "K": K,
        "density": density,
        "seed": seed,
        "feasible": result["feasible"],
        "penalty": result["penalty"],
        "runtime_ms": result["runtime_ms"],
        "opt_penalty": None,
        "approx_ratio": None,
    }

    if do_brute and result["feasible"]:
        t0 = time.perf_counter()
        opt = brute_force_optimal(inst)
        if opt:
            row["opt_penalty"] = opt["penalty"]
            row["approx_ratio"] = round(result["penalty"] / opt["penalty"], 4)

    rows.append(row)
    status = "FEASIBLE" if result["feasible"] else "INFEASIBLE"
    ratio_str = f"{row['approx_ratio']:.4f}" if row["approx_ratio"] else "N/A"
    print(f"{label:4s} n={n:3d} K={K:3d} ρ={density:.2f} | {status:10s} "
          f"penalty={result['penalty']:10.2f} ms={result['runtime_ms']:6d} "
          f"opt={row['opt_penalty'] or 'N/A'} ratio={ratio_str}")

# -----------------------------------------------------------------------
# Charts
# -----------------------------------------------------------------------
labels = [r["label"] for r in rows]
ns = [r["n"] for r in rows]
penalties = [r["penalty"] if r["feasible"] else float("nan") for r in rows]
runtimes = [r["runtime_ms"] for r in rows]

fig, axes = plt.subplots(1, 2, figsize=(12, 5))

# Chart 1: Penalty vs n
ax = axes[0]
ax.plot(ns, penalties, "o-", color="steelblue", linewidth=2, markersize=6)
for i, (x, y, lbl) in enumerate(zip(ns, penalties, labels)):
    if not math.isnan(y):
        ax.annotate(lbl, (x, y), textcoords="offset points", xytext=(4, 4), fontsize=8)
ax.set_xlabel("Number of Tasks (n)", fontsize=12)
ax.set_ylabel("Penalty P(σ)", fontsize=12)
ax.set_title("Penalty vs n", fontsize=13)
ax.grid(True, alpha=0.3)

# Chart 2: Runtime vs n
ax = axes[1]
ax.plot(ns, runtimes, "s-", color="tomato", linewidth=2, markersize=6)
for i, (x, y, lbl) in enumerate(zip(ns, runtimes, labels)):
    ax.annotate(lbl, (x, y), textcoords="offset points", xytext=(4, 4), fontsize=8)
ax.set_xlabel("Number of Tasks (n)", fontsize=12)
ax.set_ylabel("Runtime (ms)", fontsize=12)
ax.set_title("Runtime vs n", fontsize=13)
ax.grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig("benchmark_charts.png", dpi=150)
print("\nCharts saved to benchmark_charts.png")

# Save JSON results
with open("benchmark_results.json", "w") as f:
    json.dump(rows, f, indent=2)
print("Results saved to benchmark_results.json")

