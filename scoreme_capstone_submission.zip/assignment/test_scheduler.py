"""
Unit Tests for PWCFG-RALS Scheduler — Task 5 Required Tests

Tests cover:
  1. All-conflict graph (chromatic number > K) → infeasible
  2. Zero-capacity slot
  3. Tight SLA windows
  4. Single-task instance
  5. Toy instance from Section 3.3 → feasible and within bounds
  6. Penalty function properties
  7. Brute-force vs greedy agreement on small instance
"""

import pytest
from scheduler import Instance, solve, penalty, is_feasible, brute_force_optimal, generate_instance


# ---------------------------------------------------------------------------
# Helper builders
# ---------------------------------------------------------------------------

def make_instance(n, K, conflicts, resources, capacities, windows, weights):
    data = {
        "tasks": [f"T{i}" for i in range(n)],
        "conflicts": conflicts,
        "resources": resources,
        "capacities": capacities,
        "windows": windows,
        "weights": weights,
        "K": K
    }
    return Instance(data)


# ---------------------------------------------------------------------------
# Test 1: All-conflict graph with K < n — must be infeasible when K < chromatic#
# ---------------------------------------------------------------------------

class TestAllConflictGraph:
    def test_complete_graph_infeasible(self):
        """
        4 tasks all mutually conflicting, K=3 slots.
        Chromatic number of K4 = 4 > K=3 → must be infeasible.
        All SLA windows = [0, K-1] and resources trivially fit.
        """
        n, K = 4, 3
        conflicts = [(i, j) for i in range(n) for j in range(i + 1, n)]
        resources = [[1, 1, 0, 0]] * n
        capacities = [[100, 100, 100, 100]] * K
        windows = [(0, K - 1)] * n
        weights = [1.0] * n
        inst = make_instance(n, K, conflicts, resources, capacities, windows, weights)
        result = solve(inst)
        assert result["feasible"] is False, (
            "K4 graph with 3 slots must be infeasible (chromatic number = 4)")

    def test_complete_graph_feasible_enough_slots(self):
        """
        4 tasks all mutually conflicting, K=4 slots — exactly one task per slot.
        Should be feasible.
        """
        n, K = 4, 4
        conflicts = [(i, j) for i in range(n) for j in range(i + 1, n)]
        resources = [[1, 1, 0, 0]] * n
        capacities = [[100, 100, 100, 100]] * K
        windows = [(0, K - 1)] * n
        weights = [1.0] * n
        inst = make_instance(n, K, conflicts, resources, capacities, windows, weights)
        result = solve(inst)
        assert result["feasible"] is True


# ---------------------------------------------------------------------------
# Test 2: Zero-capacity slot
# ---------------------------------------------------------------------------

class TestZeroCapacitySlot:
    def test_first_slot_zero_cpu(self):
        """
        Slot 0 has 0 CPU → any task requiring CPU cannot go into slot 0.
        Two non-conflicting tasks; one must go to slot 1+.
        """
        n, K = 2, 3
        conflicts = []
        resources = [[5, 10, 0, 0], [5, 10, 0, 0]]
        capacities = [[0, 100, 100, 100], [100, 100, 100, 100], [100, 100, 100, 100]]
        windows = [(0, 2)] * n
        weights = [1.0] * n
        inst = make_instance(n, K, conflicts, resources, capacities, windows, weights)
        result = solve(inst)
        assert result["feasible"] is True
        for task, slot in result["assignment"].items():
            assert slot != 0, f"{task} placed in zero-capacity slot 0"

    def test_all_slots_zero_capacity_infeasible(self):
        """
        All slots have 0 capacity → infeasible.
        """
        n, K = 2, 2
        conflicts = []
        resources = [[5, 10, 0, 0]] * n
        capacities = [[0, 0, 0, 0]] * K
        windows = [(0, 1)] * n
        weights = [1.0] * n
        inst = make_instance(n, K, conflicts, resources, capacities, windows, weights)
        result = solve(inst)
        assert result["feasible"] is False


# ---------------------------------------------------------------------------
# Test 3: Tight SLA windows
# ---------------------------------------------------------------------------

class TestTightSLAWindows:
    def test_each_task_must_go_to_unique_slot_tight_windows(self):
        """
        3 tasks, each with a window of exactly 1 slot (lo == hi), all different slots.
        No conflicts. Should be trivially feasible with exact placement.
        """
        n, K = 3, 3
        conflicts = []
        resources = [[1, 1, 0, 0]] * n
        capacities = [[100, 100, 100, 100]] * K
        windows = [(0, 0), (1, 1), (2, 2)]
        weights = [1.0] * n
        inst = make_instance(n, K, conflicts, resources, capacities, windows, weights)
        result = solve(inst)
        assert result["feasible"] is True
        asgn = result["assignment"]
        assert asgn["T0"] == 0
        assert asgn["T1"] == 1
        assert asgn["T2"] == 2

    def test_conflicting_tasks_forced_same_slot_infeasible(self):
        """
        2 conflicting tasks both forced to slot 0 (tight windows) → infeasible.
        """
        n, K = 2, 3
        conflicts = [(0, 1)]
        resources = [[1, 1, 0, 0]] * n
        capacities = [[100, 100, 100, 100]] * K
        windows = [(0, 0), (0, 0)]  # both must be in slot 0
        weights = [1.0] * n
        inst = make_instance(n, K, conflicts, resources, capacities, windows, weights)
        result = solve(inst)
        assert result["feasible"] is False


# ---------------------------------------------------------------------------
# Test 4: Single-task instance
# ---------------------------------------------------------------------------

class TestSingleTask:
    def test_single_task_assigned_to_earliest_slot(self):
        """
        One task should be assigned and incur minimum possible penalty (slot 0 if
        resource allows, otherwise later slot within window).
        """
        n, K = 1, 4
        conflicts = []
        resources = [[4, 16, 1, 1.0]]
        capacities = [[32, 128, 8, 6.0]] * K
        windows = [(0, 3)]
        weights = [5.0]
        inst = make_instance(n, K, conflicts, resources, capacities, windows, weights)
        result = solve(inst)
        assert result["feasible"] is True
        assert result["assignment"]["T0"] == 0  # should go to earliest slot

    def test_single_task_tight_window_respected(self):
        n, K = 1, 4
        conflicts = []
        resources = [[4, 16, 1, 1.0]]
        capacities = [[32, 128, 8, 6.0]] * K
        windows = [(2, 3)]  # must be in slot 2 or 3 only
        weights = [5.0]
        inst = make_instance(n, K, conflicts, resources, capacities, windows, weights)
        result = solve(inst)
        assert result["feasible"] is True
        assert result["assignment"]["T0"] in (2, 3)


# ---------------------------------------------------------------------------
# Test 5: Toy instance from Section 3.3
# ---------------------------------------------------------------------------

class TestToyInstance:
    def get_toy(self):
        data = {
            "tasks": ["T1", "T2", "T3", "T4", "T5", "T6"],
            "conflicts": [
                [0, 1], [0, 2], [1, 3], [2, 4], [3, 5], [4, 5]
            ],
            "resources": [
                [8, 32, 4, 1.5],
                [4, 16, 0, 3.0],
                [2, 8, 0, 2.0],
                [16, 64, 2, 0.5],
                [8, 32, 2, 1.0],
                [4, 16, 0, 1.5]
            ],
            "capacities": [[32, 128, 8, 6.0]] * 4,
            "windows": [[0, 2], [0, 3], [0, 3], [1, 3], [0, 3], [1, 3]],
            "weights": [5, 4, 3, 2, 3, 2],
            "K": 4
        }
        return Instance(data)

    def test_toy_feasible(self):
        inst = self.get_toy()
        result = solve(inst)
        assert result["feasible"] is True, f"Toy infeasible: {result['violation_reason']}"

    def test_toy_sla_respected(self):
        inst = self.get_toy()
        result = solve(inst)
        asgn = result["assignment"]
        windows = [[0, 2], [0, 3], [0, 3], [1, 3], [0, 3], [1, 3]]
        task_names = ["T1", "T2", "T3", "T4", "T5", "T6"]
        for idx, name in enumerate(task_names):
            lo, hi = windows[idx]
            s = asgn[name]
            assert lo <= s <= hi, f"{name} SLA violated: slot {s} not in [{lo},{hi}]"

    def test_toy_no_conflicts(self):
        inst = self.get_toy()
        result = solve(inst)
        ok, reason = is_feasible(inst, [result["assignment"][t] for t in inst.tasks])
        assert ok, f"Feasibility check failed: {reason}"


# ---------------------------------------------------------------------------
# Test 6: Penalty function properties
# ---------------------------------------------------------------------------

class TestPenaltyFunction:
    def test_penalty_nonnegative(self):
        data = generate_instance(10, 4, seed=99)
        inst = Instance(data)
        result = solve(inst)
        assert result["penalty"] >= 0

    def test_earlier_slot_lower_base_penalty(self):
        """Moving a task to a strictly earlier slot should reduce penalty all else equal."""
        n, K = 2, 4
        conflicts = []
        resources = [[1, 1, 0, 0]] * n
        capacities = [[100, 100, 100, 100]] * K
        windows = [(0, 3)] * n
        weights = [1.0] * n
        inst = make_instance(n, K, conflicts, resources, capacities, windows, weights)
        asgn_late = [3, 3]
        asgn_early = [0, 0]
        assert penalty(inst, asgn_early) < penalty(inst, asgn_late)


# ---------------------------------------------------------------------------
# Test 7: Brute-force agreement
# ---------------------------------------------------------------------------

class TestBruteForce:
    def test_small_instance_feasible_agreement(self):
        """
        On a small feasible instance, brute force must find a valid assignment,
        and the greedy ratio must be finite (≥ 1.0).
        """
        data = generate_instance(8, 3, conflict_density=0.3, seed=1)
        inst = Instance(data)
        result = solve(inst)
        opt = brute_force_optimal(inst)
        if result["feasible"] and opt is not None:
            ratio = result["penalty"] / opt["penalty"]
            assert ratio >= 1.0 - 1e-6, "Greedy can't beat optimal"
            assert ratio < 10.0, f"Ratio suspiciously large: {ratio}"

    def test_infeasible_instance_consistent(self):
        """
        An infeasible instance must be reported as infeasible by both solvers.
        """
        n, K = 4, 2
        conflicts = [(i, j) for i in range(n) for j in range(i + 1, n)]
        resources = [[1, 1, 0, 0]] * n
        capacities = [[100, 100, 100, 100]] * K
        windows = [(0, 1)] * n
        weights = [1.0] * n
        inst = make_instance(n, K, conflicts, resources, capacities, windows, weights)
        result = solve(inst)
        opt = brute_force_optimal(inst)
        assert result["feasible"] is False
        assert opt is None


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

