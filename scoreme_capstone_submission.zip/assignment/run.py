"""
run.py — convenience alias matching the assignment's benchmark command format.
Delegates to scheduler.py main().

Usage:
  python run.py --n 8 --K 3 --density 0.3 --seed 1
  python run.py --input instance.json
  python run.py --n 8 --K 3 --density 0.3 --seed 1 --brute
"""
from scheduler import main
if __name__ == "__main__":
    main()

