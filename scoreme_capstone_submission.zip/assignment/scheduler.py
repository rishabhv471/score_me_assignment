"""
ScoreMe Engineering Capstone — Task Scheduler
Algorithm: Priority-Weighted Conflict-First Greedy with Resource-Aware Local Search (PWCFG-RALS)

Author: Candidate
Date: 2026-05-07

Design Philosophy:
    Phase 1 uses a DSATUR-inspired greedy that orders tasks by (priority_weight DESC,
    conflict_degree DESC, SLA_window_slack ASC) to assign the most-constrained,
    highest-priority tasks first. This minimises the risk of infeasibility caused by
    leaving heavily-conflicted nodes for last.

    Phase 2 applies a limited local-search pass: for each task, we attempt to move it
    to an earlier feasible slot (lower slot index = lower weighted-delay penalty). Moves
    are accepted if they (a) preserve feasibility and (b) reduce total penalty.

    The custom penalty P(σ) extends P_base with two domain-grounded terms:
        P(σ) = P_base + λ₁ × P_load_imbalance + λ₂ × P_sla_risk
    See penalty() for full definitions.
"""

import json
import time
import math
import random
import argparse
import itertools
from typing import Dict, List, Tuple, Optional

# ---------------------------------------------------------------------------
# Data Structures
# ---------------------------------------------------------------------------

class Instance:
    """Holds a parsed scheduling instance."""

    def __init__(self, data: dict):
        self.tasks: List[str] = data["tasks"]
        self.n: int = len(self.tasks)
        self.K: int = data["K"]
        # conflicts stored as adjacency set per task index
        self.conflict_adj: List[set] = [set() for _ in range(self.n)]
        for i, j in data["conflicts"]:
            self.conflict_adj[i].add(j)
            self.conflict_adj[j].add(i)
        self.resources: List[List[float]] = data["resources"]   # n x d
        self.capacities: List[List[float]] = data["capacities"] # K x d
        self.windows: List[Tuple[int, int]] = [tuple(w) for w in data["windows"]]
        self.weights: List[float] = data["weights"]
        self.d: int = len(self.capacities[0])  # number of resource dimensions

    def task_index(self, name: str) -> int:
        return self.tasks.index(name)


# ---------------------------------------------------------------------------
# Penalty Function  P(σ)  — Task 2
# ---------------------------------------------------------------------------

LAMBDA1 = 0.5   # load-imbalance weight — tunable
LAMBDA2 = 1.0   # SLA-risk weight         — tunable


def penalty(instance: Instance, assignment: List[int]) -> float:
    """
    Compute the extended penalty P(σ) for a complete assignment.

    P(σ) = P_base(σ) + λ₁ × P_load(σ) + λ₂ × P_sla_risk(σ)

    P_base(σ) = Σᵢ w(tᵢ) × (σ(tᵢ) + 1)
        Weighted slot index; +1 converts 0-indexed slots to 1-indexed delay cost.

    P_load(σ) = Σ_s Σ_d  max(0,  util_sd − avg_util_d )²
        Sum over slots and dimensions of squared over-utilisation relative to the
        mean utilisation per dimension. Penalises hot-spots. Minimising this pushes
        load toward uniform distribution — operationally desirable on shared clusters.

    P_sla_risk(σ) = Σᵢ w(tᵢ) × ( (σ(tᵢ) − lᵢ) / max(1, uᵢ − lᵢ) )²
        Quadratic proximity to the upper SLA boundary. A task assigned near its
        deadline carries higher breach risk under any jitter. Minimising this
        encourages early assignment of high-weight tasks.

    Both extensions are:
      - formally defined mathematical expressions (above)
      - computable in O(n + K·d) time given σ
      - monotonically meaningful: lower value = better operational state
      - non-trivial and domain-grounded in ScoreMe's credit pipeline context
    """
    n, K, d = instance.n, instance.K, instance.d

    # --- P_base ---
    p_base = sum(instance.weights[i] * (assignment[i] + 1) for i in range(n))

    # --- P_load ---
    util = [[0.0] * d for _ in range(K)]
    for i in range(n):
        s = assignment[i]
        for dim in range(d):
            util[s][dim] += instance.resources[i][dim]

    # average utilisation per dimension across slots
    avg_util = [0.0] * d
    for dim in range(d):
        cap_sum = sum(instance.capacities[s][dim] for s in range(K))
        res_sum = sum(util[s][dim] for s in range(K))
        avg_util[dim] = res_sum / max(1.0, cap_sum)

    p_load = 0.0
    for s in range(K):
        for dim in range(d):
            frac = util[s][dim] / max(1e-9, instance.capacities[s][dim])
            p_load += max(0.0, frac - avg_util[dim]) ** 2

    # --- P_sla_risk ---
    p_sla = 0.0
    for i in range(n):
        lo, hi = instance.windows[i]
        slack = max(1, hi - lo)
        position = (assignment[i] - lo) / slack
        p_sla += instance.weights[i] * (position ** 2)

    return p_base + LAMBDA1 * p_load + LAMBDA2 * p_sla


# ---------------------------------------------------------------------------
# Feasibility Checkers
# ---------------------------------------------------------------------------

def slot_resource_ok(instance: Instance, slot: int,
                     current_usage: List[List[float]], task_idx: int) -> bool:
    """
    Return True if assigning task_idx to slot does not exceed any resource capacity.

    Runs in O(d) time — called frequently in the inner loop.
    Justification: we maintain a running usage matrix and update it incrementally
    rather than recomputing from scratch each time (O(n·d) → O(d) per check).
    """
    for dim in range(instance.d):
        if (current_usage[slot][dim] + instance.resources[task_idx][dim]
                > instance.capacities[slot][dim] + 1e-9):
            return False
    return True


def conflict_ok(instance: Instance, slot: int,
                slot_assignment: List[set], task_idx: int) -> bool:
    """
    Return True if no task already assigned to `slot` conflicts with task_idx.

    Uses the pre-built adjacency set for O(degree) check.
    """
    for neighbour in instance.conflict_adj[task_idx]:
        if neighbour in slot_assignment[slot]:
            return True  # conflict found → NOT ok
    return False  # no conflict → ok


def is_feasible(instance: Instance, assignment: List[int]) -> Tuple[bool, str]:
    """
    Verify all three feasibility conditions F1, F2, F3 for a complete assignment.
    Returns (True, "") or (False, reason_string).
    """
    n, K, d = instance.n, instance.K, instance.d
    slot_sets: List[set] = [set() for _ in range(K)]
    usage = [[0.0] * d for _ in range(K)]

    for i in range(n):
        s = assignment[i]
        if s < 0 or s >= K:
            return False, f"Task {instance.tasks[i]} assigned to invalid slot {s}"
        # F3
        lo, hi = instance.windows[i]
        if not (lo <= s <= hi):
            return False, (f"Task {instance.tasks[i]} violates SLA: "
                           f"slot {s} not in [{lo},{hi}]")
        # F1
        for nb in instance.conflict_adj[i]:
            if nb in slot_sets[s]:
                return False, (f"Conflict: {instance.tasks[i]} and "
                               f"{instance.tasks[nb]} both in slot {s}")
        slot_sets[s].add(i)
        # F2
        for dim in range(d):
            usage[s][dim] += instance.resources[i][dim]

    for s in range(K):
        for dim in range(d):
            if usage[s][dim] > instance.capacities[s][dim] + 1e-9:
                return False, (f"Slot {s} dim {dim} overloaded: "
                               f"{usage[s][dim]:.2f} > {instance.capacities[s][dim]:.2f}")
    return True, ""


# ---------------------------------------------------------------------------
# Phase 1 — Priority-Weighted Conflict-First Greedy (PWCFG)
# ---------------------------------------------------------------------------

def greedy_assign(instance: Instance) -> Optional[List[int]]:
    """
    Assign all tasks using a DSATUR-inspired greedy ordering.

    Ordering key (descending priority):
        (weight DESC, conflict_degree DESC, sla_slack ASC)

    Rationale:
      - High-weight tasks are assigned first to allow early slots → lower P_base.
      - High-degree tasks are assigned early (DSATUR principle): they have more
        constraints and benefit most from having the most slot choices available.
      - Tight SLA tasks are assigned before loose ones to avoid them becoming
        infeasible after their slot choices are consumed by loose tasks.

    For each task, we try slots s in [lo, hi] ordered by slot index (prefer early
    slots → lower delay penalty). We accept the first slot that satisfies F1, F2, F3.

    Returns a list assignment[i] = slot index, or None if infeasible.
    """
    n, K, d = instance.n, instance.K, instance.d

    # Build ordering
    order = sorted(
        range(n),
        key=lambda i: (
            -instance.weights[i],
            -len(instance.conflict_adj[i]),
            instance.windows[i][1] - instance.windows[i][0]  # slack ASC
        )
    )

    assignment = [-1] * n
    usage = [[0.0] * d for _ in range(K)]
    slot_sets: List[set] = [set() for _ in range(K)]

    for i in order:
        lo, hi = instance.windows[i]
        placed = False
        for s in range(lo, hi + 1):
            # Check F1 (conflict)
            has_conflict = any(nb in slot_sets[s] for nb in instance.conflict_adj[i])
            if has_conflict:
                continue
            # Check F2 (resource)
            if not slot_resource_ok(instance, s, usage, i):
                continue
            # Assign
            assignment[i] = s
            slot_sets[s].add(i)
            for dim in range(d):
                usage[s][dim] += instance.resources[i][dim]
            placed = True
            break

        if not placed:
            return None  # infeasible under this ordering

    return assignment


# ---------------------------------------------------------------------------
# Phase 2 — Resource-Aware Local Search (RALS)
# ---------------------------------------------------------------------------

def local_search(instance: Instance, assignment: List[int],
                 max_iter: int = 500) -> List[int]:
    """
    Improve the greedy assignment via single-task relocation moves.

    For each task i (iterated in weight-descending order), attempt to move it to
    every slot s' in [lo, hi] that is earlier than its current slot. Accept the
    move if total penalty strictly decreases and feasibility is preserved.

    Neighbourhood: N(σ) = { σ' | σ' differs from σ in exactly one task's slot }
    Move acceptance: strict improvement (greedy descent, no random hill-climbing).

    Justification for greedy descent over SA here:
      The greedy phase already produces good solutions; SA overhead (temperature
      schedule, cooling rate tuning) is not justified for the improvement magnitude
      expected. Pure descent is fast and explainable.

    Runs at most max_iter passes or until no improvement is found.
    """
    n, K, d = instance.n, instance.K, instance.d

    # Build working structures
    usage = [[0.0] * d for _ in range(K)]
    slot_sets: List[set] = [set() for _ in range(K)]
    for i in range(n):
        s = assignment[i]
        slot_sets[s].add(i)
        for dim in range(d):
            usage[s][dim] += instance.resources[i][dim]

    current_penalty = penalty(instance, assignment)
    order = sorted(range(n), key=lambda i: -instance.weights[i])

    for _ in range(max_iter):
        improved = False
        for i in order:
            cur_s = assignment[i]
            lo, hi = instance.windows[i]

            for s in range(lo, hi + 1):
                if s >= cur_s:
                    continue  # only try earlier slots (lower delay)

                # Check F1
                has_conflict = any(nb in slot_sets[s]
                                   for nb in instance.conflict_adj[i])
                if has_conflict:
                    continue

                # Check F2: temporarily remove i from cur_s, add to s
                feasible_res = True
                for dim in range(d):
                    new_use = usage[s][dim] + instance.resources[i][dim]
                    if new_use > instance.capacities[s][dim] + 1e-9:
                        feasible_res = False
                        break
                if not feasible_res:
                    continue

                # Tentatively apply move
                old_s = cur_s
                slot_sets[old_s].discard(i)
                for dim in range(d):
                    usage[old_s][dim] -= instance.resources[i][dim]
                slot_sets[s].add(i)
                for dim in range(d):
                    usage[s][dim] += instance.resources[i][dim]
                assignment[i] = s

                new_penalty = penalty(instance, assignment)
                if new_penalty < current_penalty - 1e-9:
                    current_penalty = new_penalty
                    cur_s = s
                    improved = True
                else:
                    # Revert
                    slot_sets[s].discard(i)
                    for dim in range(d):
                        usage[s][dim] -= instance.resources[i][dim]
                    slot_sets[old_s].add(i)
                    for dim in range(d):
                        usage[old_s][dim] += instance.resources[i][dim]
                    assignment[i] = old_s

        if not improved:
            break

    return assignment


# ---------------------------------------------------------------------------
# Main Solver Entry Point
# ---------------------------------------------------------------------------

def greedy_assign_shuffled(instance: Instance, rng: random.Random) -> Optional[List[int]]:
    """
    Randomised variant of greedy_assign using a perturbed ordering.

    The base ordering (weight DESC, degree DESC, slack ASC) is preserved as the
    primary sort key, but ties are broken randomly using rng. This diversifies
    restarts so that tasks blocking each other in deterministic order get a
    different chance order. Used in the multi-start wrapper solve().
    """
    n, K, d = instance.n, instance.K, instance.d

    order = sorted(
        range(n),
        key=lambda i: (
            -instance.weights[i],
            -len(instance.conflict_adj[i]),
            instance.windows[i][1] - instance.windows[i][0],
            rng.random()  # tie-break perturbation
        )
    )

    assignment = [-1] * n
    usage = [[0.0] * d for _ in range(K)]
    slot_sets: List[set] = [set() for _ in range(K)]

    for i in order:
        lo, hi = instance.windows[i]
        placed = False
        # Try slots in random order within [lo, hi] to escape local dead-ends
        slot_order = list(range(lo, hi + 1))
        rng.shuffle(slot_order)
        # But prefer earlier slots for lower penalty — stable-sort by index after shuffle
        slot_order.sort()
        for s in slot_order:
            has_conflict = any(nb in slot_sets[s] for nb in instance.conflict_adj[i])
            if has_conflict:
                continue
            if not slot_resource_ok(instance, s, usage, i):
                continue
            assignment[i] = s
            slot_sets[s].add(i)
            for dim in range(d):
                usage[s][dim] += instance.resources[i][dim]
            placed = True
            break

        if not placed:
            return None

    return assignment


def solve(instance: Instance, max_restarts: int = 200) -> dict:
    """
    Run PWCFG-RALS on the given instance and return a result dict.

    The solver:
      1. Runs greedy_assign (Phase 1, deterministic) first.
      2. If it fails, runs up to max_restarts randomised restarts.
      3. If any restart succeeds, picks the lowest-penalty feasible solution
         and runs local_search (Phase 2) to improve it.
      4. If every restart fails, reports infeasibility.
      5. Verifies feasibility of the final solution (defensive check).

    Multi-start rationale:
      Pure greedy can fail due to ordering conflicts. Randomised restarts
      escape the deterministic dead-end at negligible cost for small K;
      for large infeasible instances they exhaust quickly (each pass is O(n·K·d)).

    Output keys match the assignment specification:
      assignment, penalty, runtime_ms, feasible, violation_reason
    """
    t0 = time.perf_counter()

    assignment = greedy_assign(instance)
    best_assignment = assignment

    if assignment is None:
        rng = random.Random(12345)
        for restart in range(max_restarts):
            candidate = greedy_assign_shuffled(instance, rng)
            if candidate is not None:
                if best_assignment is None:
                    best_assignment = candidate
                elif penalty(instance, candidate) < penalty(instance, best_assignment):
                    best_assignment = candidate

    if best_assignment is None:
        elapsed = int((time.perf_counter() - t0) * 1000)
        return {
            "assignment": {},
            "penalty": float("inf"),
            "runtime_ms": elapsed,
            "feasible": False,
            "violation_reason": (
                "No feasible assignment found after exhaustive greedy restarts. "
                "Instance is likely infeasible: check conflict density, "
                "SLA windows, and resource capacities."
            )
        }

    best_assignment = local_search(instance, best_assignment)

    elapsed = int((time.perf_counter() - t0) * 1000)
    ok, reason = is_feasible(instance, best_assignment)

    return {
        "assignment": {instance.tasks[i]: best_assignment[i] for i in range(instance.n)},
        "penalty": round(penalty(instance, best_assignment), 6),
        "runtime_ms": elapsed,
        "feasible": ok,
        "violation_reason": reason if not ok else ""
    }


# ---------------------------------------------------------------------------
# Brute-Force Optimal (small instances only, n ≤ 14)
# ---------------------------------------------------------------------------

def brute_force_optimal(instance: Instance) -> Optional[dict]:
    """
    Enumerate all K^n assignments to find the minimum-penalty feasible one.

    Only practical for n ≤ 12–14. Used to compute empirical approximation ratio
    for small benchmark instances (Tasks 5 & 6).

    Returns None if no feasible assignment exists.
    """
    n, K = instance.n, instance.K
    best_penalty = float("inf")
    best_assignment = None

    slots_per_task = [list(range(instance.windows[i][0], instance.windows[i][1] + 1))
                      for i in range(n)]

    for combo in itertools.product(*slots_per_task):
        asgn = list(combo)
        ok, _ = is_feasible(instance, asgn)
        if ok:
            p = penalty(instance, asgn)
            if p < best_penalty:
                best_penalty = p
                best_assignment = asgn[:]

    if best_assignment is None:
        return None
    return {
        "assignment": {instance.tasks[i]: best_assignment[i] for i in range(n)},
        "penalty": round(best_penalty, 6),
        "feasible": True
    }


# ---------------------------------------------------------------------------
# Instance Generator (verbatim from assignment spec, Section 5)
# ---------------------------------------------------------------------------

def generate_instance(n, K, d=4, conflict_density=0.3, seed=42):
    """
    Generate a random MSME Credit Pipeline Scheduling instance.
    Verbatim from assignment Section 5 — do not modify.
    """
    random.seed(seed)
    tasks = [f'T{i}' for i in range(n)]
    conflicts = [(i, j) for i in range(n) for j in range(i + 1, n)
                 if random.random() < conflict_density]
    cap = [32, 128, 8, 6.0]
    resources = [[random.uniform(1, cap[dd] // (n // K + 1))
                  for dd in range(4)] for _ in range(n)]
    capacities = [cap[:] for _ in range(K)]
    windows = [(lo := random.randint(0, K - 2),
                random.randint(lo + 1, K - 1)) for _ in range(n)]
    weights = [random.uniform(1, 10) for _ in range(n)]
    return dict(tasks=tasks, conflicts=conflicts,
                resources=resources, capacities=capacities,
                windows=windows, weights=weights, K=K)


# ---------------------------------------------------------------------------
# CLI Runner (run.py interface)
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="PWCFG-RALS Scheduler — ScoreMe Capstone")
    parser.add_argument("--input", type=str, help="Path to JSON instance file")
    parser.add_argument("--n", type=int, help="Number of tasks (generator mode)")
    parser.add_argument("--K", type=int, help="Number of slots (generator mode)")
    parser.add_argument("--density", type=float, default=0.3,
                        help="Conflict density (generator mode)")
    parser.add_argument("--seed", type=int, default=42,
                        help="Random seed (generator mode)")
    parser.add_argument("--brute", action="store_true",
                        help="Also run brute-force (small instances only)")
    parser.add_argument("--output", type=str, help="Write result JSON to file")
    args = parser.parse_args()

    if args.input:
        with open(args.input) as f:
            data = json.load(f)
    elif args.n and args.K:
        data = generate_instance(args.n, args.K,
                                 conflict_density=args.density, seed=args.seed)
    else:
        parser.error("Provide --input or both --n and --K")

    instance = Instance(data)
    result = solve(instance)

    if args.brute and instance.n <= 14:
        t0 = time.perf_counter()
        opt = brute_force_optimal(instance)
        bf_ms = int((time.perf_counter() - t0) * 1000)
        if opt:
            ratio = result["penalty"] / opt["penalty"] if opt["penalty"] > 0 else 1.0
            result["brute_force_penalty"] = opt["penalty"]
            result["brute_force_ms"] = bf_ms
            result["empirical_approx_ratio"] = round(ratio, 4)
        else:
            result["brute_force_penalty"] = None
            result["brute_force_ms"] = bf_ms
            result["empirical_approx_ratio"] = None

    out = json.dumps(result, indent=2)
    print(out)
    if args.output:
        with open(args.output, "w") as f:
            f.write(out)


if __name__ == "__main__":
    main()


